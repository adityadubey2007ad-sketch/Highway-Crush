# Highway Crush — Android Project

This is the Android WebView wrapper for the Highway Crush HTML game.

## Requirements
- Android Studio Ladybug or newer (recommended), or JDK 17 + Android SDK 35
- Android Gradle Plugin 8.6.1
- Gradle 8.10.2

## Build APK in Android Studio
1. Open this folder as an existing Android Studio project.
2. Let Gradle sync finish.
3. Select **Build → Generate App Bundles or APKs → Generate APKs**.
4. The debug APK will be at:
   `app/build/outputs/apk/debug/app-debug.apk`

## Build without Android Studio
Run:
`gradle --no-daemon assembleDebug`

## GitHub Actions build (no local Android setup)
Create a GitHub repository, upload this project, push to `main`, then open **Actions → Build Highway Crush APK**. The workflow builds the debug APK and uploads it as an artifact.

## App details
- Name: Highway Crush
- Application ID: `com.highwaycrush.app`
- Portrait orientation
- Fullscreen WebView
- JavaScript + localStorage enabled for the game's saved progress
- Game is bundled locally; no internet is required to play
